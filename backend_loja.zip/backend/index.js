const express = require('express');
const app = express();
const produtoRoutes = require('./routes/produto');
const sequelize = require('./db');

app.use(express.json());
app.use('/render', produtoRoutes);

sequelize.sync().then(() => {
  console.log('Banco de dados sincronizado.');
  app.listen(3000, () => console.log('API rodando na porta 3000'));
});