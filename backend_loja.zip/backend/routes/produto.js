const express = require('express');
const router = express.Router();
const Produto = require('../models/Produto');
const authMiddleware = require('../middleware/auth');

router.post('/produtos', authMiddleware, async (req, res) => {
  const { name, price, imageUrl, description } = req.body;
  if (!name || !price || !imageUrl || !description) {
    return res.status(400).json({ error: 'Todos os campos são obrigatórios.' });
  }
  try {
    const produto = await Produto.create({ name, price, imageUrl, description });
    res.status(201).json(produto);
  } catch (err) {
    res.status(500).json({ error: 'Erro ao adicionar produto.' });
  }
});

router.get('/produtos', async (req, res) => {
  try {
    const produtos = await Produto.findAll();
    res.json(produtos);
  } catch (err) {
    res.status(500).json({ error: 'Erro ao listar produtos.' });
  }
});

module.exports = router;