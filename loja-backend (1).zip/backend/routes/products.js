const express = require('express');
const pool = require('../db');
const autenticar = require('../middleware/auth');

const router = express.Router();

router.get('/', async (req, res) => {
  const result = await pool.query('SELECT * FROM products');
  res.json(result.rows);
});

router.post('/', autenticar, async (req, res) => {
  const { name, price } = req.body;
  await pool.query('INSERT INTO products (name, price) VALUES ($1, $2)', [name, price]);
  res.json({ message: 'Produto adicionado!' });
});

module.exports = router;