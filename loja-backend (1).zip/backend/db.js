const { Pool } = require('pg');

const pool = new Pool({
  connectionString: 'COLE_AQUI_SUA_CONNECTION_STRING_DO_NEON'
});

module.exports = pool;